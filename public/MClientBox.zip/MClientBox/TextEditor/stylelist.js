var style_list = new Array (
    {'name': 'para1', 'title': '단락', 'css': 'wym_containers_p'},
    {'name': 'para2', 'title': '본문', 'css': 'wym_containers_pre'},
    {'name': 'para3', 'title': '제목', 'css': 'wym_containers_blockquote'},
    {'name': 'para4', 'title': '부제목', 'css': 'wym_containers_th'},
    {'name': 'para5', 'title': '캡션', 'css': 'wym_containers_h1'},
    {'name': 'para6', 'title': '사진설명', 'css': 'wym_containers_h2'}
);
